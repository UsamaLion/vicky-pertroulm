<div class="container">
    <div class="status">
        <h1 class="error">Your PayPal Transaction has been Canceled</h1>
    </div>
    <a href="index.php" class="btn-link">Back to Products</a>
</div>