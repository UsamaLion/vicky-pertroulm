<?php
	$con = ($GLOBALS["artist"] = mysqli_connect('localhost','root','','artist')) or die("Problem occur in DB connection");  
?>
